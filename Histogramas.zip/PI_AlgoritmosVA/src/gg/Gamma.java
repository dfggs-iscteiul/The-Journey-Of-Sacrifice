package gg;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;

public class Gamma {

	private static DecimalFormat df = new DecimalFormat("0");
	
	public static void generateNumbers() throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter writer = new PrintWriter("Gamma.txt", "UTF-8");
		double A=1 / Math.sqrt(2*2-1);
		double B = 2 - Math.log(4);
		double Q = 2 + 1/A;
		double T = 4.5;
		double D = 1 + Math.log(T);
		for(int i =0; i<1000;i++) {
			while(true){
				double p1 = Math.random();
				double p2 = Math.random();
				double v = A*Math.log(p1/(1-p1));
				double y = 2*Math.exp(v);
				double z = p1*p1*p2;
				double w = B+Q*v-y;
				if(w+D-T*z>=0 || w>=Math.log(z)) {
					if(Integer.parseInt(df.format(0+1*y))==0) {
						break;
					}
					else {
					writer.println(df.format(0+1*y));
					break;
					}
				}
			}
		}
		writer.close();
	}
	
	
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
		// TODO Auto-generated method stub
		generateNumbers();
		System.out.println("Gamma has finished!");
	}

}
