package gg;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.Random;

public class Geom�trica {

	private static DecimalFormat df = new DecimalFormat("#");
	
	public static void generateNumbers() throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter writer = new PrintWriter("Geometrica.txt", "UTF-8");
		for(int i =0; i<1000;i++) {
			writer.println(df.format(Math.floor(Math.log(Math.random())/Math.log(1-(0.65)))));
		}
		writer.close();
	}
	
	
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
		// TODO Auto-generated method stub
		generateNumbers();
		System.out.println("Geom�trica has finished!");
	}

}
