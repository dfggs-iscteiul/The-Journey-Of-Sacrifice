package gg;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.Random;

public class Normal {

	private static DecimalFormat df = new DecimalFormat("0");
	
	public static void generateNumbers() throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter writer = new PrintWriter("Normal.txt", "UTF-8");
		double p=0.0;
		for(int i =0; i<1000;i++) {
			do{
				Random r = new Random();
				double p1 = Math.random()*(1-(-1))+(-1);
				double p2 = Math.random()*(1-(-1))+(-1);
				p=p1*p1+p2*p2;
				if(p<1) {
				System.out.println(50+8*p1*Math.sqrt(-2*Math.log(p)/p));
				writer.println(df.format(50+8*p1*Math.sqrt((-2)*Math.log(p)/p)));
				i++;
				}
				i--;
				break;
					} while(p>=1);
			}
		writer.close();
	}
	
	
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
		// TODO Auto-generated method stub
		generateNumbers();
		System.out.println("Normal has finished!");
	}

}
