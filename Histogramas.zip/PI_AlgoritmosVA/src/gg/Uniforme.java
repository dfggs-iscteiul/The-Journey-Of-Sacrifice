package gg;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.util.Random;

public class Uniforme {

	private static DecimalFormat df = new DecimalFormat("#");
	
	public static void generateNumbers() throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter writer = new PrintWriter("Uniforme.txt", "UTF-8");
		for(int i =0; i<1000;i++) {
			writer.println(df.format(Math.floor(1+4*Math.random())));
		}
		writer.close();
	}
	
	
	public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
		// TODO Auto-generated method stub
		generateNumbers();
		System.out.println("Uniforme has finished!");
	}

}
